package org.dbi.smir.security;

public class GuavaHashGenerator extends ParentHashGenerator
{
    @Override
    public String generateSha256Hex(String source)
    {
    }
}
